--
-- PostgreSQL database dump
--

\restrict eQnJPKhmAs0cixwbwWevoeacTzGonLAaVSIduGKVNsk2xPoyD8UDVCH6ua2whWG

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg13+1)
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: friend_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.friend_requests (
    id integer NOT NULL,
    "senderId" integer NOT NULL,
    "receiverId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.friend_requests OWNER TO postgres;

--
-- Name: friend_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.friend_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.friend_requests_id_seq OWNER TO postgres;

--
-- Name: friend_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.friend_requests_id_seq OWNED BY public.friend_requests.id;


--
-- Name: friends; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.friends (
    "user1Id" integer NOT NULL,
    "user2Id" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.friends OWNER TO postgres;

--
-- Name: games; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.games (
    id integer NOT NULL,
    "player1Id" integer NOT NULL,
    "player2Id" integer NOT NULL,
    "startTime" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endTime" timestamp(3) without time zone,
    status text DEFAULT 'en_cours'::text NOT NULL,
    "winnerId" integer,
    "timeControl" text DEFAULT '5+0'::text NOT NULL,
    "isRated" boolean DEFAULT true NOT NULL,
    "fenString" text NOT NULL
);


ALTER TABLE public.games OWNER TO postgres;

--
-- Name: games_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.games_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.games_id_seq OWNER TO postgres;

--
-- Name: games_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.games_id_seq OWNED BY public.games.id;


--
-- Name: moves; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.moves (
    id integer NOT NULL,
    "gameId" integer NOT NULL,
    "playerId" integer NOT NULL,
    "moveNumber" integer NOT NULL,
    "fromSquare" text NOT NULL,
    "toSquare" text NOT NULL,
    piece text NOT NULL,
    "isCheck" boolean DEFAULT false NOT NULL,
    "isCheckmate" boolean DEFAULT false NOT NULL,
    "isCastle" boolean DEFAULT false NOT NULL,
    "isEnPassant" boolean DEFAULT false NOT NULL,
    "promotionPiece" text,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.moves OWNER TO postgres;

--
-- Name: moves_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.moves_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.moves_id_seq OWNER TO postgres;

--
-- Name: moves_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.moves_id_seq OWNED BY public.moves.id;


--
-- Name: user_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_stats (
    "userId" integer NOT NULL,
    "totalGames" integer DEFAULT 0 NOT NULL,
    wins integer DEFAULT 0 NOT NULL,
    losses integer DEFAULT 0 NOT NULL,
    draws integer DEFAULT 0 NOT NULL,
    "eloHistory" jsonb,
    "favoriteOpening" text
);


ALTER TABLE public.user_stats OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    "hashedPassword" text NOT NULL,
    "eloRating" integer DEFAULT 500 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "avatarUrl" text,
    bio text,
    "currentGameId" integer,
    "lastSeen" timestamp(3) without time zone,
    "isAdmin" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: waitlistEntry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."waitlistEntry" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "timeControl" text DEFAULT '5+0'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."waitlistEntry" OWNER TO postgres;

--
-- Name: waitlistEntry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."waitlistEntry_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."waitlistEntry_id_seq" OWNER TO postgres;

--
-- Name: waitlistEntry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."waitlistEntry_id_seq" OWNED BY public."waitlistEntry".id;


--
-- Name: friend_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friend_requests ALTER COLUMN id SET DEFAULT nextval('public.friend_requests_id_seq'::regclass);


--
-- Name: games id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.games ALTER COLUMN id SET DEFAULT nextval('public.games_id_seq'::regclass);


--
-- Name: moves id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moves ALTER COLUMN id SET DEFAULT nextval('public.moves_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: waitlistEntry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."waitlistEntry" ALTER COLUMN id SET DEFAULT nextval('public."waitlistEntry_id_seq"'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
39faaad8-f228-4982-ac3d-81f5fbb42f50	9374b90e2d4b72b049e666ffa58fa85c6064ccda3ed6b52af0f42f63d7cb79ac	2026-07-18 13:39:59.199514+00	20260625021617_init_db	\N	\N	2026-07-18 13:39:58.639242+00	1
11628f94-bc83-4f67-879f-65c05c0d08bd	60bba7b7d23a6a19491b92238f77471113262593c5a225a64ceb5ce836c6edb7	2026-07-18 13:39:59.284202+00	20260710000000_add_friend_requests	\N	\N	2026-07-18 13:39:59.205609+00	1
0b1fb293-f192-4b5d-b832-290109858759	48495f181a48f94e257f433bfb96d0691cd8baa6394f9cea669e47ffd8fdea2a	2026-07-18 13:39:59.309538+00	20260710000001_add_last_seen	\N	\N	2026-07-18 13:39:59.290364+00	1
71912c1b-3735-464d-9578-2416f3a0bfc7	5cc870f4edd207c677798f4c844aa5ec46ec1e7cd371328aaa69db19fbfcedc8	2026-07-20 18:44:27.432102+00	20260720000000_add_is_admin	\N	\N	2026-07-20 18:44:27.356182+00	1
\.


--
-- Data for Name: friend_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.friend_requests (id, "senderId", "receiverId", "createdAt") FROM stdin;
\.


--
-- Data for Name: friends; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.friends ("user1Id", "user2Id", "createdAt") FROM stdin;
37	38	2026-07-20 18:44:30.58
37	39	2026-07-20 18:44:30.589
\.


--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.games (id, "player1Id", "player2Id", "startTime", "endTime", status, "winnerId", "timeControl", "isRated", "fenString") FROM stdin;
20	37	38	2026-07-20 18:44:30.603	2026-07-20 18:44:30.602	terminee	37	5+0	t	r1bqkbnr/pppp1ppp/2n5/4p3/1b1P4/2P2N2/PP2PPPP/RNBQKB1R w KQkq - 2 4
\.


--
-- Data for Name: moves; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.moves (id, "gameId", "playerId", "moveNumber", "fromSquare", "toSquare", piece, "isCheck", "isCheckmate", "isCastle", "isEnPassant", "promotionPiece", "timestamp") FROM stdin;
90	20	37	1	e2	e4	P	f	f	f	f	\N	2026-07-20 18:44:30.616
91	20	38	2	e7	e5	P	f	f	f	f	\N	2026-07-20 18:44:30.616
92	20	37	3	d2	d4	P	f	f	f	f	\N	2026-07-20 18:44:30.616
\.


--
-- Data for Name: user_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_stats ("userId", "totalGames", wins, losses, draws, "eloHistory", "favoriteOpening") FROM stdin;
37	49	6	4	2	[500, 620, 710, 780]	Sicilienne
38	50	7	3	2	[500, 620, 710, 845]	Italienne
39	51	5	4	2	[500, 620, 710, 910]	Italienne
40	52	6	3	2	[500, 620, 710, 690]	Italienne
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, "hashedPassword", "eloRating", "createdAt", "updatedAt", "lastLogin", "isActive", "avatarUrl", bio, "currentGameId", "lastSeen", "isAdmin") FROM stdin;
37	alice	alice@example.com	$2b$10$l./dM3p3iv0SvyYrIosIW.OL0ii.TBVrn9Vs1pBAgP0lo798B7Vj2	780	2026-07-20 18:44:30.361	2026-07-20 18:44:30.361	\N	t	https://api.dicebear.com/9.x/bottts/svg?seed=alice	Joue les ouvertures agressives et les blitz du soir.	\N	\N	f
39	carla	carla@example.com	$2b$10$7u8BLOzsNASMxKQfbxJ41.FBTUMFx29GRfvUNCFQvclvLaf812oce	910	2026-07-20 18:44:30.502	2026-07-20 18:44:30.502	\N	t	https://api.dicebear.com/9.x/bottts/svg?seed=carla	Toujours prête pour une revanche.	\N	\N	f
40	david	david@example.com	$2b$10$tFmvnpV1pa3b1NEmaDR1/.e35F6XnH7w19C9b7PE0Wa9H3RolQIha	690	2026-07-20 18:44:30.565	2026-07-20 18:44:30.565	\N	t	https://api.dicebear.com/9.x/bottts/svg?seed=david	Apprend en jouant et adore les parties rapides.	\N	\N	f
38	bob	bob@example.com	$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	845	2026-07-20 18:44:30.438	2026-07-20 18:48:49.232	\N	t	https://api.dicebear.com/9.x/bottts/svg?seed=bob	Privilégie les finales propres et les parties longues.	\N	2026-07-20 18:48:49.231	t
\.


--
-- Data for Name: waitlistEntry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."waitlistEntry" (id, "userId", "timeControl", "createdAt") FROM stdin;
30	39	10+0	2026-07-20 18:44:30.596
\.


--
-- Name: friend_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.friend_requests_id_seq', 2, true);


--
-- Name: games_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.games_id_seq', 20, true);


--
-- Name: moves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.moves_id_seq', 92, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 40, true);


--
-- Name: waitlistEntry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."waitlistEntry_id_seq"', 30, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: friend_requests friend_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friend_requests
    ADD CONSTRAINT friend_requests_pkey PRIMARY KEY (id);


--
-- Name: friends friends_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friends
    ADD CONSTRAINT friends_pkey PRIMARY KEY ("user1Id", "user2Id");


--
-- Name: games games_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_pkey PRIMARY KEY (id);


--
-- Name: moves moves_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moves
    ADD CONSTRAINT moves_pkey PRIMARY KEY (id);


--
-- Name: user_stats user_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_stats
    ADD CONSTRAINT user_stats_pkey PRIMARY KEY ("userId");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: waitlistEntry waitlistEntry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."waitlistEntry"
    ADD CONSTRAINT "waitlistEntry_pkey" PRIMARY KEY (id);


--
-- Name: friend_requests_receiverId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "friend_requests_receiverId_idx" ON public.friend_requests USING btree ("receiverId");


--
-- Name: friend_requests_senderId_receiverId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "friend_requests_senderId_receiverId_key" ON public.friend_requests USING btree ("senderId", "receiverId");


--
-- Name: friends_user1Id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "friends_user1Id_idx" ON public.friends USING btree ("user1Id");


--
-- Name: friends_user2Id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "friends_user2Id_idx" ON public.friends USING btree ("user2Id");


--
-- Name: moves_gameId_moveNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "moves_gameId_moveNumber_idx" ON public.moves USING btree ("gameId", "moveNumber");


--
-- Name: user_stats_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_stats_userId_key" ON public.user_stats USING btree ("userId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_username_key ON public.users USING btree (username);


--
-- Name: waitlistEntry_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "waitlistEntry_userId_key" ON public."waitlistEntry" USING btree ("userId");


--
-- Name: friend_requests friend_requests_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friend_requests
    ADD CONSTRAINT "friend_requests_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: friend_requests friend_requests_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friend_requests
    ADD CONSTRAINT "friend_requests_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: friends friends_user1Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friends
    ADD CONSTRAINT "friends_user1Id_fkey" FOREIGN KEY ("user1Id") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: friends friends_user2Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friends
    ADD CONSTRAINT "friends_user2Id_fkey" FOREIGN KEY ("user2Id") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: games games_player1Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT "games_player1Id_fkey" FOREIGN KEY ("player1Id") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: games games_player2Id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT "games_player2Id_fkey" FOREIGN KEY ("player2Id") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: games games_winnerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT "games_winnerId_fkey" FOREIGN KEY ("winnerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: moves moves_gameId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moves
    ADD CONSTRAINT "moves_gameId_fkey" FOREIGN KEY ("gameId") REFERENCES public.games(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: moves moves_playerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moves
    ADD CONSTRAINT "moves_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_stats user_stats_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_stats
    ADD CONSTRAINT "user_stats_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_currentGameId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_currentGameId_fkey" FOREIGN KEY ("currentGameId") REFERENCES public.games(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: waitlistEntry waitlistEntry_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."waitlistEntry"
    ADD CONSTRAINT "waitlistEntry_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict eQnJPKhmAs0cixwbwWevoeacTzGonLAaVSIduGKVNsk2xPoyD8UDVCH6ua2whWG

